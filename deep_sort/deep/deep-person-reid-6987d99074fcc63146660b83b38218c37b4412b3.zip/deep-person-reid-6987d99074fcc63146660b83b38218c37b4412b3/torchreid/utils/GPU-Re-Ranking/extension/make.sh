cd adjacency_matrix
python setup.py install
cd ../propagation
python setup.py install