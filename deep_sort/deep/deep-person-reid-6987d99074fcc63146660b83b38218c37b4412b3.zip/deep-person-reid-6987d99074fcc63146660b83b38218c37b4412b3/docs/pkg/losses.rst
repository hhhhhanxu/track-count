.. _torchreid_losses:

torchreid.losses
=================


Softmax
--------

.. automodule:: torchreid.losses.cross_entropy_loss
    :members:


Triplet
-------

.. automodule:: torchreid.losses.hard_mine_triplet_loss
    :members: